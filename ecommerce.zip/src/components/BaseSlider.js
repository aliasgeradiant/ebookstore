import React, { useEffect } from 'react';
import Slider from 'react-slick';


const BaseSlider = ({title, data}) => {
  
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };

  console.log('data', data?.[0].price)
  
  return (
    <div className='baseslider mt-5'>
        <h3 className='text-start'>{title}</h3>

        <Slider {...settings}>
          {
            data?.map(item => {
              const price = Object.entries(item.price).map(key => {
                return {
                  key: key,
                  value: item.price[1]
                }
              });

              console.log(price)
              
              return (<div className='item' key={item.id}>
                  <img src={item.image} alt='' />

                  <div className='content'>
                      <p className='author'>{item.author}</p>
                      <h5>{item.title}</h5>
                      <span>
                          {/* {
                            Object.keys(item.price).map((key, i) => )
                          } */}
                      </span>
                  </div>
              </div>)
            })
          }
        </Slider>
    </div>
  )
}

export default BaseSlider
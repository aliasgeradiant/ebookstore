import React, { useEffect, useState } from 'react'
import { getAllCategoriesHandler } from '../backend/controllers/CategoryController';

const Category = () => {
    const [category, setCategory] = useState([]);
    useEffect(() => {
        setCategory(getAllCategoriesHandler);
    }, []);

    // console.log(category.data?.categories)

    return (
        <div className='category-wrapper mt-3'>
            {
                category.data?.categories.map(item => <div className='card' key={item._id}>{item.categoryName}</div>)
            }
        </div>
    )
}

export default Category
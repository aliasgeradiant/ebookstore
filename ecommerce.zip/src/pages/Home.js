import React, { useEffect, useState } from 'react'
import { Container } from 'react-bootstrap'
import Category from '../components/Category'
import BaseSlider from '../components/BaseSlider'
import {getAllProductsHandler} from "../backend/controllers/ProductController"

const Home = () => {
    const [bestseller, setBestseller] = useState([]);

    useEffect(() => {
        setBestseller(getAllProductsHandler);
    }, [])

    console.log(bestseller.data?.products)

    return (
        <div className='home'>
            <Container>
                <section>
                    <h3 className='pt-2 m-0 text-start'>Category</h3>
                    <Category />

                    <BaseSlider title="Best Sellers" data={bestseller.data?.products} />
                </section>
            </Container>
        </div>
    )
}

export default Home